CTEST_OUTPUT_ON_FAILURE
-----------------------

.. include:: ENV_VAR.txt

Boolean environment variable that controls if the output should be logged for
failed tests. Set the value to ``1``, ``True``, or ``ON`` to enable output on failure.
See :manual:`ctest(1)` for more information on controlling output of failed
tests.
